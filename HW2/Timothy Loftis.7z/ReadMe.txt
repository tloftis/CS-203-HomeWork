To use:

Install Java SE Development Kit 8 or higher (http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)

Compile main.java through the commandline/terminal with the command "javac -g main.java"

Run the the program with the command "java main (location of data file)"



